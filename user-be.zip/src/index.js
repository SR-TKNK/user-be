const container = require("./Container");

container.resolve("app").start();